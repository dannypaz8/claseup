// BORRA TODO ESTE ARCHIVO Y PEGA TU JAVASCRIPT ACA.

console.log("La plantilla esta andando. Pega tu codigo en este archivo.");
